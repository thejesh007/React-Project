require('./db')
const express = require('express')
const loginRoutes = require('./routes/api/login');

const bodyParser = require('body-parser')
const cors = require('cors')
const path = require('path');

var postMessageRoutes = require('./controllers/postMessageController')
var personalMessageRoutes = require('./controllers/personalMessageController')
var employmentMessageRoutes = require('./controllers/employmentMessageController')
var educationMessageRoutes = require('./controllers/educationMessageController')
var appliedMessageRoutes = require('./controllers/appliedMessageController')
var savedMessageRoutes = require('./controllers/savedMessageController')



var app = express()
app.use(bodyParser.json())
app.use(cors({origin:'http://localhost:3000'}))
app.listen(4000,()=>console.log('Server started at : 4000'))


app.use('/postMessages',postMessageRoutes)
app.use('/personalMessages',personalMessageRoutes)
app.use('/employmentMessages',employmentMessageRoutes)
app.use('/educationMessages',educationMessageRoutes)
app.use('/savedMessageController',savedMessageRoutes)
app.use('/appliedMessageController',appliedMessageRoutes)

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin,X-Requested-With, Content-Type,Accept,Authorzation");
    res.header("Access-Control-Allow-Methods", 'PUT,POST,GET,DELETE,OPTIONS');
    next();
  })
  
  app.use('/api/user', loginRoutes);
  app.use((req, res, next) => {
    res.send('Welcome to Express');
  });
  
  app.use('/api', (req, res, next) => {
    next();
  });
  
  