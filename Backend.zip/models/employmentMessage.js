const mongoose = require('mongoose')

var EmploymentMessage = mongoose.model('EmploymentMessage',
{
    currentEmployer : {type:String},
    designation : {type:String},
    jobDescription1 : {type:String},
    experience1 : {type:String},
    previousEmployer : {type:String},
    jobDescription2 : {type:String},
    experience2 : {type:String}
   
},'employmentMessages')

module.exports = { EmploymentMessage}