const mongoose = require('mongoose')

var PersonalMessage = mongoose.model('PersonalMessage',
{
    name : {type:String},
    emailid : {type:String},
    password : {type:String},
    mobileno : {type:String},
    Address : {type:String},
    city : {type:String},
    state1 : {type:String},
    postalcode : {type:String},
    totalwork : {type:String},
    skills : {type:String},
    uploadresume : {type:String}
},'personalMessages')

module.exports = { PersonalMessage}