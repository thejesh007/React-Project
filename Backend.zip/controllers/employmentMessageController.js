const express = require('express')
var router = express.Router()
var ObjectID = require('mongoose').Types.ObjectId


var { EmploymentMessage } = require('../models/employmentMessage')


router.get('/', (req, res) => {
    EmploymentMessage.find((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 2))
    })
})

router.post('/', (req, res) => {
    var newRecord = new EmploymentMessage({
        currentEmployer: req.body.currentEmployer,
        designation: req.body.designation,
        jobDescription1: req.body.jobDescription1,
        experience1: req.body.experience1,
        previousEmployer: req.body.previousEmployer,
        jobDescription2: req.body.jobDescription2,
        experience2: req.body.experience2





    })

    newRecord.save((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while creating new record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.put('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    var updatedRecord = {
        currentEmployer: req.body.currentEmployer,
        designation: req.body.designation,
        jobDescription1: req.body.jobDescription1,
        experience1: req.body.experience1,
        previousEmployer: req.body.previousEmployer,
        jobDescription2: req.body.jobDescription2,
        experience2: req.body.experience2


    }

    EmploymentMessage.findByIdAndUpdate(req.params.id, { $set: updatedRecord },{new:true}, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while updating a record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.delete('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    EmploymentMessage.findByIdAndRemove(req.params.id, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while deleting a record : ' + JSON.stringify(err, undefined, 2))
    })
})


module.exports = router