const express = require('express')
var router = express.Router()
var ObjectID = require('mongoose').Types.ObjectId


var { PersonalMessage } = require('../models/personalMessage')


router.get('/', (req, res) => {
    PersonalMessage.find((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 2))
    })
})

router.post('/', (req, res) => {
    var newRecord = new PersonalMessage({
        name: req.body.name,
        emailid: req.body.emailid,
        password: req.body.password,
        mobileno: req.body.mobileno,
        Address: req.body.address,
        city: req.body.city,
        state1: req.body.state,
        postalcode: req.body.postalcode,
        country: req.body.country,
        totalwork: req.body.totalwork,
        skills: req.body.skills,
        uploadresume: req.body.uploadresume
       





    })

    newRecord.save((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while creating new record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.put('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    var updatedRecord = {
        name: req.body.name,
        emailid: req.body.emailid,
        password: req.body.password,
        mobileno: req.body.mobileno,
        Address: req.body.Address,
        city: req.body.city,
        state1: req.body.state1,
        postalcode: req.body.postalcode,
        country: req.body.country,
        totalwork: req.body.totalwork,
        skills: req.body.skills,
        uploadresume: req.body.uploadresume
       
    }

    PersonalMessage.findByIdAndUpdate(req.params.id, { $set: updatedRecord },{new:true}, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while updating a record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.delete('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    PersonalMessage.findByIdAndRemove(req.params.id, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while deleting a record : ' + JSON.stringify(err, undefined, 2))
    })
})


module.exports = router