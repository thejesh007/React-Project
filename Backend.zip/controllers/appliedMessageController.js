const express = require('express');

const router = express.Router();

var {BlogPost4} = require('../models/appliedMessage');


// Routes
router.get('/appliedJobs', (req, res) => {
    BlogPost4.find((err, docs) => {
        if (!err){
            res.send(docs)
        }
        else
         console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 2))
    });
});


router.post('/appliedJobs',(req,res) => {

    console.log('name: ',req.body);
    const data = req.body;

    const newBlogPost = new BlogPost4(data);

    newBlogPost.save((error) => {
        if (error) {
            res.status(500).json({ msg: 'Sorry, internal server errors' });
            return;
        }
        // BlogPost
        return res.json({
            msg: 'Your data has been saved!!!!!!'
        });
    });
});




module.exports = router;