import React, { Component } from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';

class AlljobComponent2 extends Component {
    state = {
        posts: []
    };
    componentDidMount = () => {
        this.getBlogPost();
    };
    getBlogPost = () => {
        axios.get('http://localhost:4000/postMessages')
            .then((response) => {
                const data = response.data;
                this.setState({ posts: data });
            });
    }

    displayBlogPost = (posts) => {
        if (!posts.length) return null;
        return posts.map((post, index) => (

            <div key={index} className="blog-post__display">


                <h4>Company name : {post.companyname}</h4>
                <p>title : {post.jtitle}</p>
                <p>Role : {post.role}</p>
        <p>Salary Range :{post.salaryrange}</p>
        <p>Responsibility :{post.responsibility}</p>

        < NavLink to="/home" class="nav-link active">      <button type="submit" class="btn btn-primary">Please Login to Apply</button></ NavLink>

        
            </div>

        ));
    };
    render() {
        return (<div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
  
            <div>
                

                <div className="blog-">
                    {this.displayBlogPost(this.state.posts)}
                </div>
            </div>
            </div>
        )
    }
}

export default AlljobComponent2;