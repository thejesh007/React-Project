import React from 'react';
import { NavLink } from 'react-router-dom';

class LoginComponent extends React.Component{
    constructor(){
        super();
        this.state=
        {
            err : ''
        };
    }
    login(e){
        e.preventDefault();
        var username = e.target.elements.username.value;
        var password = e.target.elements.password.value;
        if(username === 'thejesh' && password === '12345'){
            this.props.history.push('/viewform' );

        }else{
this.setState({
    err: 'Invalid'
});
        }
    }

    render() {
        let format={
            color : "red"
        };
        const myform = {
          width: '300px',
          margin: '0 auto',
          
        }
        return(
        <div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
      
      <div  className="bglo">

  
<form style={myform}>
            <div>
                           <h3>Job Portal Admin</h3>
                <span style={format}>{this.state.err !== '' ? this.state.err : ''}
                </span>          
                
                           {/* <form method="post" onSubmit ={this.login.bind(this)} >
                               Username <input type="text" name="username"/>
                               <br/>
                               Password <input type="password" name="password"/>
                               <br/>
                               <input type="submit" value="Login"/>
                           </form> */}
                           <form method="post" onSubmit ={this.login.bind(this)}>
  <div class="form-group">
    <label for="username">User Name</label>
    <input type="text" class="form-control" id="username" aria-describedby="username"/>
    
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password"/>
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
            </div> 
            </form>  
            </div>   
            </div>
                    
        );
    }
}
export default LoginComponent;