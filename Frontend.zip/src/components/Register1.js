import React from "react";
import { useHistory } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route } from 'react-router-dom';
import { NavLink } from 'react-router-dom';





import axios from "axios";


class Register1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      input: {},
      errors: {}
    };
    this.baseState = this.state

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange = (event) => {
    let input = this.state.input;
    input[event.target.name] = event.target.value;

    this.setState({
      input
    });
  }

  handleReset = (event => {
    event.preventDefault();
    let input = {};
    input["firstName"] = "";
    input["middleName"] = "";
    input["lastName"] = "";
    input["email"] = "";
    input["mobileNo"] = "";
    input["address"] = "";
    input["userId"] = "";
    input["password"] = "";
    input["message"] = "";

    this.setState(this.baseState)

    this.setState({ input: input });
  })

  handleSubmit = (event, history) => {
    event.preventDefault();

    if (this.validate()) {
      console.log(this.state);

      //reset after registration!
      /* let input = {};
       input["firstName"] = "";
       input["middleName"] = "";
       input["lastName"] = "";
       input["email"] = "";
       input["mobileNo"] = "";
       input["address"] = "";
       input["userId"] = "";
       input["password"] = "";
       input["message"]="";
       
       this.setState({input:input});*/

      console.log(this.state.input)  
      alert('Please wait Taking to you next page');

      // post data in database
      axios
        .post("http://localhost:4000/api/user/register", this.state.input)
        .then(res => {
          console.log(res);
        })
        .catch(error => {
          console.log(error);
        });

      if (history) {
        history.push("/education1");
      }

    }
  }

  validate() {
    let input = this.state.input;
    let errors = {};
    let isValid = true;

    //required fields
    if ((!input["firstName"]) || (!input["lastName"]) || (!input["email"]) || (!input["mobileNo"]) ||
      (!input["address"]) || (!input["userId"]) || (!input["password"])) {
      isValid = false;
      errors["message"] = "All * mentioned fields are mandatory.";
    }

    else {
      //username validation
      if (typeof input["userId"] !== "undefined") {

        var pattern = new RegExp(/[*^#!~|\"%:<>[\]{}`\\()';@&$]/);
        if (pattern.test(input["userId"])) {
          isValid = false;
          errors["userId"] = "Username should not contain special characters.";
        }
      }

      //password validation
      if (typeof input["password"] !== "undefined") {

        var pattern = new RegExp(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/);
        if (!pattern.test(input["password"])) {
          isValid = false;
          errors["password"] = "Password must be at least 8 characters long, should contain at-least 1 Uppercase,1 Lowercase,1 Numeric and 1 special character."
        }
      }

      //mobile no. validation
      if (typeof input["mobileNo"] !== "undefined") {

        var pattern = new RegExp(/^[0-9\b]+$/);

        if (!pattern.test(input["mobileNo"])) {

          isValid = false;

          errors["mobileNo"] = "Please enter only number.";

        } else if (input["mobileNo"].length != 10) {

          isValid = false;

          errors["mobileNo"] = "Please enter valid phone number.";

        }

      }

      //email validation
      if (typeof input["email"] !== "undefined") {

        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        if (!pattern.test(input["email"])) {
          isValid = false;
          errors["email"] = "Please enter valid email address.";
        }
      }
    }
    this.setState({
      errors: errors
    });

    return isValid;


  }



  render() {
    return (
        <div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob1" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
        
            <div>
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item">
          <NavLink to="/personal1" class="nav-link active" id="pills-home-tab" data-toggle="pill" role="tab" aria-controls="pills-home" aria-selected="true">Personal</NavLink>
        </li>
        
        <li class="nav-item">
          <NavLink to="/education1" class="nav-link disabled" id="pills-contact-tab" data-toggle="pill"  role="tab" aria-controls="pills-contact" aria-selected="false">Education</NavLink>
        </li>
      </ul>
      <>
      <div className="container">
      <form className="registerForm" onSubmit={this.handleSubmit}>

<div className="form-group" style={{ display: "flex" }} >
  <label className="control-label col-sm-2 "> </label>
  <div className="col-sm-11">
    <input
      type="text" placeholder= "FirstName" style={{ height: '90%', width: '40%' }} className="form-control input-sm"
      name="firstName"
      maxLength="25"
      onChange={this.handleChange} value={this.state.input.firstName}
      required
    />
  </div>
</div>

<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="MiddleName" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="middleName"
      onChange={this.handleChange} value={this.state.input.middleName}
    />
  </div>
</div>

<div className="form-group" style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="LastName" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="lastName"
      maxLength="25" onChange={this.handleChange} value={this.state.input.lastName} required
    />
  </div>
</div>

<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="Email" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="email"
      onChange={this.handleChange} value={this.state.input.email} required
    />
    <div className="text-danger">{this.state.errors.email}</div>
  </div>
</div>

<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="Mobile" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="mobileNo"
      onChange={this.handleChange} value={this.state.input.mobileNo} required
    />
    <div className="text-danger">{this.state.errors.mobileNo}</div>
  </div>
</div>


<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="Address" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="address"
      maxLength="50"
      onChange={this.handleChange} value={this.state.input.address} required
    />
  </div>
</div>
<div className="form-group" style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="Total Work" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="work"
      maxLength="25" onChange={this.handleChange} value={this.state.input.work} required
    />
  </div>
</div>
<div className="form-group" style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="Skills" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="skills"
      maxLength="25" onChange={this.handleChange} value={this.state.input.skills} required
    />
  </div>
</div>
<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2 "></label>
  <div className="col-sm-11">
    <input type="text" placeholder="UserId" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="userId"
      onChange={this.handleChange} value={this.state.input.userId} required
    />
    <div className="text-danger">{this.state.errors.userId}</div>
  </div>
</div>

<div className="form-group " style={{ display: "flex" }}>
  <label className="control-label col-sm-2"></label>
  <div className="col-sm-11">
    <input type="password" placeholder="password" style={{ height: '90%', width: '40%' }}
      className="form-control input-sm"
      name="password"
      onChange={this.handleChange} value={this.state.input.password} required
    />
    <div className="text-danger">{this.state.errors.password}</div>
  </div>
</div>
<div class="form-group" style={{ display: "flex" }}>
    <div class="custom-file">
    <div className="col-sm-11">
      <input type="file" placeholder="Upload Resume" class="custom-file-input" id="validatedInputGroupCustomFile" required/>
      <label class="custom-file-label" for="validatedInputGroupCustomFile">Upload Resume</label>
    </div>
    </div>
    </div>


<div className="form-group" style={{ display: "flex" }}>
  <label className="control-label col-sm-2"></label>
  <div className="col-sm-offset-2 col-sm-11">
    <div className="text-danger">{this.state.errors.message}</div><br></br>
    <Route render={({ history }) => (
      <button type="submit" className="btn btn-primary mr-2" onClick={(e) => this.handleSubmit(e, history)}>Next</button>
    )} />

    <button type="reset" className="btn btn-primary" onClick={this.handleReset}>Reset</button>
  </div>
</div>
</form>
        </div>
        
      </>
      </div></div>
    )
  }

}
export default Register1;

