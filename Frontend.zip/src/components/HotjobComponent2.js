import React, { Component } from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';

class HotjobComponent2 extends Component {
    state = {
        posts: []
    };
    componentDidMount = () => {
        this.getBlogPost();
    };
    getBlogPost = () => {
        axios.get('http://localhost:4000/postMessages')
            .then((response) => {
                const data = response.data;
                this.setState({ posts: data });
            });
    }

    displayBlogPost = (posts) => {
        if (!posts.length) return null;
        return posts.map((post, index) => (

            <div key={index} className="blog-post__display" >

                <div class="column" >

                    <div class="row">
                    <div class="card bg-secondary " >
                            <div class="card-body">
                                <h5 class="card-title"><h4>  < NavLink to="/alljob" class="nav-link active">{post.companyname}</NavLink>
                                </h4>title : {post.jtitle}</h5>
                                <p class="card-text">Role : {post.role}</p>
                                <p class="card-text">Experience : {post.experience}</p>

                                <p class="card-text">Salary : {post.salaryrange}</p>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
        ));
    };
    render() {
        return (
            <div>
                <h5>HOT JOBS</h5>

                <div className="blog-">
                    {this.displayBlogPost(this.state.posts)}
                </div>
            </div>
        )
    }
}

export default HotjobComponent2;