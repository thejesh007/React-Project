import React, {Component} from 'react';
import axios from 'axios';
import profile from "../images/profile.png";

import { NavLink } from 'react-router-dom';

 class ProfileComponent extends Component{
     
    state={
        posts :[]
    };
    componentDidMount = () =>{
        this.getBlogPost();
    };
    getBlogPost = () => {
        axios.get('http://localhost:4000/api/user/all')
        .then((response)=>{
            const data= response.data;
            this.setState({ posts :data});
        });
    }
 
    displayBlogPost = (posts) =>{
if(!posts.length) return null;
return posts.map((post,index) => (
    
    <div key={index} className="blog-post__display">
        
        <table class="table">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">First Name</th>
      <th scope="col">Middle Name</th>
      <th scope="col">Last Name</th>

      <th scope="col">User Name</th>
      <th scope="col">Email id</th>
      <th scope="row">Address</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="col"></th>
      <td>{post.firstName}</td>
      <td>{post.middleName}</td>
      <td>{post.lastName}</td>

      <td>{post.username}</td>
      <td>{post.email}</td>
      <td>{post.address}</td>
    </tr>
    
  </tbody>
</table>

    </div>
))  ;
    };
    render(){
        return(
            <div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home1" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
      <nav class="nav flex-column">
            < NavLink to ="/applied"  class="nav-link active">  <img src={profile} width="100" height="100" padding="60" /></ NavLink>
          
  < NavLink to ="/applied"  class="nav-link active">Applied Jobs</NavLink>
  < NavLink to ="/saved"  class="nav-link active">Saved Jobs</NavLink>
  < NavLink to ="/profile"  class="nav-link active">Profile Details</NavLink>

</nav>
        <div>
<h2>Profile Details</h2>
            <div className="blog-">
                {this.displayBlogPost(this.state.posts)}
            </div>
        </div>
        </div>
        )
}
 }

export default ProfileComponent;