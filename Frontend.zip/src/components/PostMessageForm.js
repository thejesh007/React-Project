import React, { useEffect, useState } from "react";
import { TextField, withStyles, Button } from "@material-ui/core";
import useForm from "./useForm";
import { connect } from "react-redux";
import * as actions from "../actions/postMessage";
import ButterToast, { Cinnamon } from "butter-toast";
import { AssignmentTurnedIn } from "@material-ui/icons";

const initialFieldValues = {
    jid: '',
    jtitle: '',
    role: '',
    responsibility:'',
    companyname: '',
    experience:'',
    salaryrange:'',
    noofpositions:'',
    location: '',
    skills :'',
    degree :'',
    companyinfo: '',
    employeetype: '',
    industrytype: '',
    searchkeyword: '',
    jobdescription: ''
}

const styles = theme => ({
    root: {
        '& .MuiTextField-root': {
            margin: theme.spacing(1)
        },
    },
    form: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center'
    },
    postBtn: {
        width: "50%"
    }
})

const PostMessageForm = ({ classes, ...props }) => {

    useEffect(() => {
        if (props.currentId != 0){
            setValues({
                ...props.postMessageList.find(x => x._id == props.currentId)
            })
            setErrors({})
        }
    }, [props.currentId])

    const validate = () => {
        let temp = { ...errors }
        temp.jid = values.jid ? "" : "This field is required."
        temp.jtitle = values.jtitle ? "" : "This field is required."
        temp.role = values.role ? "" : "This field is required."
        temp.responsibility = values.responsibility ? "" : "This field is required."
        temp.companyname = values.companyname ? "" : "This field is required."
        temp.experience = values.experience ? "" : "This field is required."
        temp.salaryrange = values.salaryrange ? "" : "This field is required."
        temp.noofpositions = values.noofpositions ? "" : "This field is required."
        temp.location = values.location ? "" : "This field is required."
        temp.skills = values.skills ? "" : "This field is required."
        temp.degree = values.degree ? "" : "This field is required."
        temp.companyinfo = values.companyinfo ? "" : "This field is required."
        temp.employeetype = values.employeetype ? "" : "This field is required."
        temp.industrytype = values.industrytype ? "" : "This field is required."
        temp.searchkeyword = values.searchkeyword ? "" : "This field is required."
        temp.jobdescription = values.jobdescription ? "" : "This field is required."
       
        setErrors({
            ...temp
        })
        return Object.values(temp).every(x => x == "")
    }

    var {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFieldValues,props.setCurrentId)

    const handleSubmit = e => {
        e.preventDefault()
        const onSuccess = () => {
          alert("Form Added Successfully");
            resetForm()
        }
        if (validate()) {
            if (props.currentId == 0)
                props.createPostMessage(values, onSuccess)
            else
                props.updatePostMessage(props.currentId, values, onSuccess)
        }
    }

    return (
        <form autoComplete="off" noValidate className={`${classes.root} ${classes.form}`}
            onSubmit={handleSubmit}>
            <TextField
                name="jid"
                //variant="outlined"
                label="Job Id"
                fullWidth
                value={values.jid}
                onChange={handleInputChange}
                {...(errors.jid && { error: true, helperText: errors.jid })}
            />
            <TextField
                name="jtitle"
               // variant="outlined"
                label="Job Title"
                fullWidth
                value={values.jtitle}
                onChange={handleInputChange}
                {...(errors.jtitle && { error: true, helperText: errors.jtitle })}
            />
            <TextField
                name="role"
                //variant="outlined"
                label="Role"
                fullWidth
                value={values.role}
                onChange={handleInputChange}
                {...(errors.role && { error: true, helperText: errors.role })}
            />
            <TextField
                name="responsibility"
               // variant="outlined"
                label="Responsibility"
                fullWidth
                multiline
                rows={4}
                value={values.responsibility}
                onChange={handleInputChange}
                {...(errors.responsibility && { error: true, helperText: errors.responsibility })}
            />
            <TextField
                name="companyname"
               // variant="outlined"
                label="Company Name"
                fullWidth
                multiline
                rows={2}
                value={values.companyname}
                onChange={handleInputChange}
                {...(errors.companyname && { error: true, helperText: errors.companyname })}
            />
            <TextField
                name="experience"
               // variant="outlined"
                label="Experience"
                fullWidth
                
                value={values.experience}
                onChange={handleInputChange}
                {...(errors.experience && { error: true, helperText: errors.experience })}
            />
            <TextField
                name="salaryrange"
               // variant="outlined"
                label="Salary Range"
                fullWidth
               
                value={values.salaryrange}
                onChange={handleInputChange}
                {...(errors.salaryrange && { error: true, helperText: errors.salaryrange })}
            />
             <TextField
                name="noofpositions"
               // variant="outlined"
                label="No of Positions"
                fullWidth
                
                value={values.noofpositions}
                onChange={handleInputChange}
                {...(errors.noofpositions && { error: true, helperText: errors.noofpositions })}
            />
             <TextField
                name="location"
               // variant="outlined"
                label="Location"
                fullWidth
               
                value={values.location}
                onChange={handleInputChange}
                {...(errors.location && { error: true, helperText: errors.location })}
            />
             <TextField
                name="skills"
               // variant="outlined"
                label="Skills"
                fullWidth
                
                value={values.skills}
                onChange={handleInputChange}
                {...(errors.skills && { error: true, helperText: errors.skills })}
            />
             <TextField
                name="degree"
               // variant="outlined"
                label="Degree"
                fullWidth
               
                value={values.degree}
                onChange={handleInputChange}
                {...(errors.degree && { error: true, helperText: errors.degree })}
            />
             <TextField
                name="companyinfo"
               // variant="outlined"
                label="Company Info"
                fullWidth
               
                value={values.companyinfo}
                onChange={handleInputChange}
                {...(errors.companyinfo && { error: true, helperText: errors.companyinfo })}
            />
             <TextField
                name="employeetype"
               // variant="outlined"
                label="Employee Type"
                fullWidth
               
                value={values.employeetype}
                onChange={handleInputChange}
                {...(errors.employeetype && { error: true, helperText: errors.employeetype })}
            />
             <TextField
                name="industrytype"
               // variant="outlined"
                label="Industry Type"
                fullWidth
                
                value={values.industrytype}
                onChange={handleInputChange}
                {...(errors.industrytype && { error: true, helperText: errors.industrytype })}
            />
             <TextField
                name="searchkeyword"
               // variant="outlined"
                label="Search Keyword"
                fullWidth
                
                value={values.searchkeyword}
                onChange={handleInputChange}
                {...(errors.searchkeyword && { error: true, helperText: errors.searchkeyword })}
            />
             <TextField
                name="jobdescription"
               // variant="outlined"
                label="Job Description"
                fullWidth
                multiline
                rows={5}
                value={values.jobdescription}
                onChange={handleInputChange}
                {...(errors.jobdescription && { error: true, helperText: errors.jobdescription })}
            />
            
            <Button
                variant="contained"
                color="primary"
                size="large"
                type="submit"
                className={classes.postBtn}
            >Add</Button>
        </form>
    );
}


const mapStateToProps = state => ({
    postMessageList: state.postMessage.list
})

const mapActionToProps = {
    createPostMessage: actions.create,
    updatePostMessage: actions.update
}


export default connect(mapStateToProps, mapActionToProps)(withStyles(styles)(PostMessageForm));