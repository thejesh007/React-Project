import React, { Component } from 'react';
import HotjobComponent from "./HotjobComponent";
import { NavLink } from 'react-router-dom';
import SearchBar from "material-ui-search-bar";
import { ArrowRight } from '@material-ui/icons';
import amazon from "../images/amazon.png";
import microsoft from "../images/microsoft.jpg";
import google from "../images/google.jpeg";
import paypal from "../images/paypal.jpg";
import cocacola from "../images/cocacola.png";
import axios from 'axios';

import apple from "../images/apple.png";
import samsung from "../images/samsung.png";
import tata from "../images/tata.jpg";


import Login from './Login';
import FooterComponent from './FooterComponent';


class HomepageComponent extends React.Component {
 
constructor() {
    super();
    this.location = "";
    this.skills = "";
    this.state = {
        searchData: "",
        err: ''
    }
}
getRelavantJobs(location, skills) {
  console.log(skills);
  console.log(location);
  if (!skills && !location) {
      this.setState({ searchData: '' });
  } else {
      fetch("http://localhost:4000/postMessages/searchJobs?location=" + location + "&skills=" + skills).then((data) => {
          data.json().then((res) => {
              console.warn("res", res);
              console.log(res);
              console.log('heree')
              this.setState({ searchData: res });
          });
      });
  }

}



  
  login(e) {
    e.preventDefault();
    var email = e.target.elements.email.value;
    var password = e.target.elements.password.value;
    if (email === 'thejeshreddy98@gmail.com' && password === '12345') {
      this.props.history.push('/userlogin');

    } else {
      this.setState({
        err: 'Invalid'
      });
    }
  }

  render() {

    let format = {
      color: "red"
    };
    const my = {
      width: "20%",
      padding: "10px 20px",
      margin: "60px 7px",
      boxSizing: "border-box",
      border: "2px solid #6495ED",
      borderRadius: "4px"
    }


    return (<div> <nav class="navbar navbar-expand-lg navbar-light bg-primary">
      <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            < NavLink to="/adminlogin" class="nav-link active">Admin Login</NavLink>
          </li>
          <li class="nav-item active">
            < NavLink to="/alljob1" class="nav-link active">All Jobs</NavLink>
          </li>
          <li class="nav-item active">
            < NavLink to="/companies" class="nav-link active">Companies</NavLink>
          </li>


        </ul>

      </div>
    </nav>
    <div  className="bglogo">
   
      <div>


        <form style={{ marginRight: "0px" }}>
         <Login/>

          < NavLink to="/personal1" class="nav-link active">Register as Fresher </NavLink>
          < NavLink to="/personal" class="nav-link active">Register as Experienced </NavLink>

        </form>
        <div className="row">
                    <div className="col">
                        <input type="text" placeholder="Search By Location" style={my}
                            onChange={(event) => { this.location = event.target.value; this.getRelavantJobs(this.location, this.skills) }} />
                        <input type="text" placeholder="Search by Skills" style={my}
                            onChange={(event) => { this.skills = event.target.value; this.getRelavantJobs(this.location, this.skills) }}
                        />
                        </div>
                </div>
                <div>
                    {
                        this.state.searchData ?
                            <div>
                                {
                                    this.state.searchData.map((item) =>
                                        <div>
                                            <div >

                                                <div class="card-body">
                                                    <h5 class="card-title">{item.companyname}</h5>

                                                    <p class="card-text">Location: {item.location}</p>
                                                    <p class="card-text">Skills Required: {item.skills}</p>
                                                    < NavLink to="/" class="nav-link active"> <button type="submit" class="btn btn-primary"
                                                       
                                                      disabled={this.state.disabled} >Login to Apply  </button></ NavLink>
                                                </div>
                                            </div>
                                        </div>)

                                }
                            </div>
                            : ""

                    }
                </div>
        <div>
        <h4 >Hot Hires</h4>
        <div >
          < img src={amazon} width="200" height="200" padding="60" />
          <img src={microsoft} width="200" height="200" padding="60" />
          <img src={google} width="200" height="200" padding="60" />
        
          <img src={paypal} width="200" height="200" padding="60" />
        
          <img src={samsung} width="200" height="200" padding="60" />
  <img src={cocacola} width="200" height="200" padding="60" />
          <img src={apple} width="200" height="200" padding="60" />

        </div>
        </div>
        <div>
          <HotjobComponent/>
          </div>
        
        <div>
        <h4>Career tips</h4>
<p><li>A break helps. ...</li>       
<li>  Seek help building your resume. ...</li>
</p><br/>
<p><li>List your strengths. ...</li>
<li>Online job boards. ...</li>
</p><br/>
<p><li>Make the most of your networking skills. ...
</li>
<li>Research your employer. ...
</li>
</p><br/>
<p><li> Sport a smile. ...
</li>
<li>Always look presentable. ...
</li>
</p><br/>
</div>

      </div>
    </div></div>
    );
  }
}
export default HomepageComponent;