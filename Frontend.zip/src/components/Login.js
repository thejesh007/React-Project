import React from "react";
import "./login.css";



import { BrowserRouter as Router, Route, Link, Redirect, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

class Login extends React.Component {
  constructor(props) {
    super();
    this.state = {
      username: "",
      password: "",
      message: "",
      textStyle: ""
    }
  }

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
      message: ''
    })
  }

  handleSubmit = (e,history) => {
    e.preventDefault();


    if (this.state.username === '') {
      alert('you need to enter the username')
    }
    if (this.state.password === '') {
      alert('you need to enter the password')

    }

    let reqBody = {
      "username": this.state.username,
      "password": this.state.password
    }
    fetch('http://localhost:4000/api/user/login', {
      method: 'POST',
      body: JSON.stringify(reqBody),
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(response => {
      if (response.status >= 200 && response.status < 300) {
       
       
        
         if(history){
          history.push('./userlogin')
        }
         /*swal({
           title:"successfully login",
           text:"",
           icon:"success",
           button:"ok"
         })*/

        console.log(response);
        //window.location.reload();
      } else {
        this.setState({
          message: "incorrect username or password",
          textStyle: "danger"
        })
      }
    })
  }



  render() {
    return (



        <div style={{ marginRight: "0px" }} >
          <div style={{ marginRight: "0px" }}>
        
           <div className="form-group " >

           <h2 >Login</h2>

              <form className="loginForm" onSubmit={this.handleSubmit}  >
               
                


                


                <div className="form-group " >

                  <label><span className="fa fa-user" style={{ fontSize: "28px" }}></span> </label>

                  <div className="col-sm-12">


                    <input type="text"
                      className="form-control" placeholder="Username"
                      name="username" onChange={this.handleChange} required
                    />
                  </div>
                </div>

                <div className="form-group" >
                  <label><span className="fa fa-lock" style={{ fontSize: "28px" }}></span> </label>

                  <div className="col-sm-12">
                    <input type="password"
                      className="form-control" placeholder="Password"
                      name="password" onChange={this.handleChange} required
                    />
                  </div>
                </div>


               
                <div className="col-sm-12" style={{ marginLeft: "0px" }}>

                 
                    {this.state.message !== '' && <div className={`text text-${this.state.textStyle}`}>{this.state.message}</div>}<br />
                    
                    <Route render={({ history }) => (
                    <button type="submit" className="form-control" onClick={(e) => this.handleSubmit(e, history)} >Submit</button>
                )} />

              </div>

              </form>
            </div>
          </div>
          </div>
        

     
    )
  }
}


export default Login;

