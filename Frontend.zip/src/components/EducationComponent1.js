import React from 'react';
import { Component } from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';

class EducationComponent1 extends Component{

    state = {
        
        college: '',
        year: '',
        graduated: '',
        graduateschool: '',
        numberofyears: '',
        skills: '',
        certification: '',
        
    }

    handleChange = ({ target }) => {
        const { name, value } = target;
        this.setState({ [name]: value });
      };

      submit = (e) => {
          e.preventDefault();
          const payload = {
            college:this.state.college,
            year:this.state.year,
            graduated:this.state.graduated,
            graduateschool:this.state.graduateschool,
            numberofyears:this.state.numberofyears,
            skills:this.state.skills,
            certification:this.state.certification,
            

    
        };
    
    
        axios({
          url: 'http://localhost:4000/educationMessages',
          method: 'POST',
          data: payload
        })
          .then(() => {
            console.log('Data has been sent to the server');
           
          })
          .catch(() => {
            console.log('Internal server error');
          });;

          alert("Regisration Success");

      }
    render(){
        const mystyle = {
            width: "50%",
            padding: "10px",
            margin: "10px",
            boxSizing: "border-box",
            border: "2px solid #6495ED",
            borderRadius: "4px"
        }
        const mybtn = {

            width: "20%",
            margin: "10px",
         
        }

        const header2 = {
            color: "Tomato",
            marginTop: "50px",
            textDecoration: "underline"
        }
        return (<div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob1" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
            <div>
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item">
          <NavLink to="/personal1" class="nav-link " id="pills-home-tab" data-toggle="pill" role="tab" aria-controls="pills-home" aria-selected="true">Personal</NavLink>
        </li>
       
        <li class="nav-item">
          <NavLink to="/education1" class="nav-link active" id="pills-contact-tab" data-toggle="pill"  role="tab" aria-controls="pills-contact" aria-selected="false">Education</NavLink>
        </li>
      </ul>
        <div className="container">
            

            
            <form onSubmit={this.submit} method="POST">
           

            <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text"  placeholder="Enter college name" class="form-control" id="college" 
                        onChange={this.handleChange} name="college" style={{ height: '90%', width: '40%' }}
                        value={this.state.college} required />
                </div>
</div>

<div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <textarea placeholder="enter year"  class="form-control" id="email" 
                        onChange={this.handleChange} name="year" style={{ height: '90%', width: '40%' }}
                        value={ this.state.year} required/>
                </div>
</div>

<div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Graduated year" class="form-control" id="email" 
                        onChange={this.handleChange} name="graduated"style={{ height: '90%', width: '40%' }}
                        value={this.state.graduated} required/>
                   </div>
                </div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Graduated School" class="form-control" id="email" 
                        onChange={this.handleChange} name="graduateschool" style={{ height: '90%', width: '40%' }}
                        value={this.state.graduateschool} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="No of years attented" class="form-control" id="email" 
                        onChange={this.handleChange} name="numberofyears" style={{ height: '90%', width: '40%' }}
                        value={this.state.numberofyears} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Skills" class="form-control" id="email" 
                        onChange={this.handleChange} name="skills" style={{ height: '90%', width: '40%' }}
                        value={this.state.skills} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Certification" class="form-control" id="email" 
                        onChange={this.handleChange} name="certification"style={{ height: '90%', width: '40%' }}
                        value={this.state.certification} required/>
                   
                </div></div>

               



                



                <button type="submit" class="btn btn-primary mr-2"     
                 disabled={this.state.disabled}>Submit</button>

            </form>
        </div>
    </div>
    </div>
);
    }
}


export default EducationComponent1;