import React from "react";
import "./Footer.css";

function FooterComponent() {

    return (

        <div className="main-footer">

            <div className="container">

                <div className="row">

                    <p className="col-sm">

                        &copy; {new Date().getFullYear()} Online Job Portal | ALL rights reserved

Terms Of Service | Privacy

</p>

                </div>

            </div>

        </div>

);
}
export default FooterComponent;