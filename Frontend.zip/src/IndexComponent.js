import React from 'react';
import { BrowserRouter,Switch,Route } from 'react-router-dom';
import App from './App';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import AddComponent from './components/AddComponent';
import HomepageComponent from './components/HomepageComponent';
import LoginComponent from './components/LoginComponent';
import PostMessages from './components/PostMessages';
import UserComponents from './components/UserComponents';
import AppliedjobComponent from './components/AppliedjobComponent';
import SavedjobComponent from './components/SavedjobComponent';
import ProfileComponent from './components/ProfileComponent';
import ExperiencedComponent from './components/ExperiencedComponent';
import FooterComponent from './components/FooterComponent';
import AlljobComponent from './components/AlljobComponent';
import CompanyComponent from './components/CompanyComponent';
import EmploymentComponent from './components/EmploymentComponent';
import HomepageComponent2 from './components/HomePageComponent2';
import EducationComponent from './components/EducationComponent';
import EducationComponent1 from './components/EducationComponent1';
import ViewComponent from './components/ViewComponent';
import Test from './components/Test';
import Register from './components/Register';
import Login from './components/Login';
import Register1 from './components/Register1';
import AlljobComponent2 from './components/AlljobComponent2';
import AlljobComponent3 from './components/AlljobComponent3';






class IndexComponent extends React.Component{

    render() {
        
        return(
          

            <BrowserRouter>
            <Switch>
                <Route exact path= "/" component={HomepageComponent}/>
                <Route path="/userlogin" component={HomepageComponent2}/>
                <Route path="/applied" component={AppliedjobComponent}/>
                <Route  path= "/alljob" component={AlljobComponent}/>
                <Route  path= "/alljob1" component={AlljobComponent2}/>

                <Route  path= "/companies" component={CompanyComponent}/>
                <Route path="/saved" component={SavedjobComponent}/>
                <Route path="/profile" component={ProfileComponent}/>
                <Route path ="/experienced" component={ExperiencedComponent}/>
                <Route path ="/adminlogin" component={LoginComponent}/>
                <Route  path= "/welcome" component={AddComponent}/>
                <Route  path= "/employment" component={EmploymentComponent}/>
                <Route  path= "/personal1" component={Register1}/>
                <Route  path= "/home" component={HomepageComponent}/>
                <Route  path= "/logout" component={HomepageComponent}/>
                <Route  path= "/usercom" component={UserComponents}/>
                <Route  path= "/education" component={EducationComponent}/>
                <Route  path= "/home1" component={HomepageComponent2}/>
                <Route  path= "/personal" component={Register}/>
                <Route  path= "/education1" component={EducationComponent1}/>

                <Route  path= "/logout2" component={LoginComponent}/>


                <Route  path= "/addform" component={App}/>
                <Route  path= "/viewform" component={AlljobComponent3}/>
              



            </Switch>
          <div>  <FooterComponent/></div>
            </BrowserRouter>
            
        );
    }
}
export default IndexComponent;